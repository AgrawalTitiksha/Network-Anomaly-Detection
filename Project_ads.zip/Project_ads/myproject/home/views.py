from django.shortcuts import render,HttpResponse
import joblib
model=joblib.load('static/random_forest.pkl')
# Create your views here.
def index(request):
    # return HttpResponse("Thsi ....")
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def prediction(request):
    if request.method == "POST":
        print("enter into the post request")
        proc_type = request.POST.get('proc_type')
        service = request.POST.get('service')
        flag = request.POST.get('flag')
        logged_in = request.POST.get('logged_in')
        count = request.POST.get('count')
        srv_serror_rate = request.POST.get('srv_serror_rate')
        srv_rerror_rate = request.POST.get('srv_rerror_rate')
        same_srv_rate = request.POST.get('same_srv_rate')
        diff_srv_rate = request.POST.get('diff_srv_rate')
        dst_host_count = request.POST.get('dst_host_count')
        dst_host_srv_count = request.POST.get('dst_host_srv_count')
        dst_host_same_srv_rate = request.POST.get('dst_host_same_srv_rate')
        dst_host_diff_srv_rate = request.POST.get('dst_host_diff_srv_rate')
        dst_host_same_src_port_rate = request.POST.get('dst_host_same_src_port_rate')
        dst_host_serror_rate = request.POST.get('dst_host_serror_rate')
        dst_host_rerror_rate = request.POST.get('dst_host_rerror_rate')

        print(proc_type, service, flag, logged_in, count, srv_serror_rate, srv_rerror_rate, same_srv_rate, diff_srv_rate, dst_host_count, dst_host_srv_count, dst_host_same_srv_rate, dst_host_diff_srv_rate, dst_host_same_src_port_rate, dst_host_serror_rate, dst_host_rerror_rate)
        pred = model.predict ([[proc_type, service, flag, logged_in, count, srv_serror_rate, srv_rerror_rate, same_srv_rate, diff_srv_rate, dst_host_count, dst_host_srv_count, dst_host_same_srv_rate, dst_host_diff_srv_rate, dst_host_same_src_port_rate, dst_host_serror_rate, dst_host_rerror_rate]])
        print(pred)
        output={
            "output":pred
        }
        return render(request,'prediction.html',output)

    else:
        return render(request,'prediction.html')
# from sklearn.preprocessing import OneHotEncoder
# from sklearn.compose import ColumnTransformer

# # Assuming 'proc_type', 'service', and 'flag' are categorical variables


# def prediction(request):
#     if request.method == "POST":
#         print("enter into the post request")
#         proc_type = str(request.POST.get('proc-type', ''))
#         service = str(request.POST.get('service', ''))
#         flag = str(request.POST.get('flag', ''))
#         logged_in = request.POST.get('logged_in', '')
#         count = int(request.POST.get('count', 0))
#         srv_serror_rate = float(request.POST.get('srv_serror_rate', 0))
#         srv_rerror_rate = float(request.POST.get('srv_rerror_rate', 0))
#         same_srv_rate = float(request.POST.get('same_srv_rate', 0))
#         diff_srv_rate = float(request.POST.get('diff_srv_rate', 0))
#         dst_host_count = int(request.POST.get('dst_host_count', 0))
#         dst_host_srv_count = int(request.POST.get('dst_host_srv_count', 0))
#         dst_host_same_srv_rate = float(request.POST.get('dst_host_same_srv_rate', 0))
#         dst_host_diff_srv_rate = float(request.POST.get('dst_host_diff_srv_rate', 0))
#         dst_host_same_src_port_rate = float(request.POST.get('dst_host_same_src_port_rate', 0))
#         dst_host_serror_rate = float(request.POST.get('dst_host_serror_rate', 0))
#         dst_host_rerror_rate = float(request.POST.get('dst_host_rerror_rate', 0))

#         print(proc_type, service, flag, logged_in, count, srv_serror_rate, srv_rerror_rate, same_srv_rate, diff_srv_rate, dst_host_count, dst_host_srv_count, dst_host_same_srv_rate, dst_host_diff_srv_rate, dst_host_same_src_port_rate, dst_host_serror_rate, dst_host_rerror_rate)
#         pred = model.predict([[proc_type, service, flag, logged_in, count, srv_serror_rate, srv_rerror_rate, same_srv_rate, diff_srv_rate, dst_host_count, dst_host_srv_count, dst_host_same_srv_rate, dst_host_diff_srv_rate, dst_host_same_src_port_rate, dst_host_serror_rate, dst_host_rerror_rate]])
#         print(pred)
#         output = {
#             "output": pred
#         }
#         return render(request, 'prediction.html', output)

#     else:
#         return render(request, 'prediction.html')


